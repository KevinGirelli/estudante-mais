import { Component } from '@angular/core';

@Component({
  selector: 'app-assessments',
  standalone: true,
  imports: [],
  templateUrl: './assessments.component.html',
  styleUrl: './assessments.component.scss'
})
export class AssessmentsComponent {

}
